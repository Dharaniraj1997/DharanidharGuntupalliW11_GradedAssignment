import requests
import json

#url = "http://127.0.0.1:5000/predict"
#url = "http://127.0.0.1:5000/info"
url = "http://127.0.0.1:5000/health"

data = [
    {
        "radius_mean": 1.2, 
        "texture_mean": 1.2, 
        "perimeter_mean": 1.2, 
        "area_mean": 1.2, 
        "smoothness_mean": 1.2, 
        "compactness_mean": 1.2, 
        "concavity_mean": 1.2, 
        "concave points_mean": 1.2, 
        "symmetry_mean": 1.2, 
        "fractal_dimension_mean": 1.2, 
        "radius_se": 1.2, 
        "texture_se": 1.2, 
        "perimeter_se": 1.2, 
        "area_se": 1.2, 
        "smoothness_se": 1.2, 
        "compactness_se": 1.2, 
        "concavity_se": 1.2, 
        "concave points_se": 1.2, 
        "symmetry_se": 1.2, 
        "fractal_dimension_se": 1.2, 
        "radius_worst": 1.2, 
        "texture_worst": 1.2, 
        "perimeter_worst": 1.2, 
        "area_worst": 1.2, 
        "smoothness_worst": 1.2, 
        "compactness_worst": 1.2, 
        "concavity_worst": 1.2, 
        "concave points_worst": 1.2, 
        "symmetry_worst": 1.2, 
        "fractal_dimension_worst": 1.2
    }
]

headers = {
    "Content-Type": "application/json"
}

#for predict
#response = requests.post(url,data=json.dumps(data),headers=headers)
#for info
response = requests.get(url)

print(response.text)